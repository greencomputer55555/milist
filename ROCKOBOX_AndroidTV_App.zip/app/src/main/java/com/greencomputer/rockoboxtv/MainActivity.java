package com.greencomputer.rockoboxtv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private String currentServerHost = "";
    private ServerSocket controlServerSocket;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean scanning = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Mantener pantalla siempre encendida y en pantalla completa real sin bordes
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        activarPantallaCompletaInmersiva();

        prefs = getSharedPreferences("RockoboxTVPrefs", MODE_PRIVATE);
        currentServerHost = prefs.getString("serverHost", "");

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        // DESBLOQUEO TOTAL DE AUTOPLAY CON AUDIO EN ANDROID TV (Sin necesidad de presionar OK)
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setCacheMode(WebSettings.LOAD_NO_CACHE);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                mostrarPantallaBuscandoRockola("Buscando ROCKOBOX PLUS en la red Wi-Fi...");
                buscarRockolaEnRedLocal();
            }
        });

        iniciarServidorControlRemotoPuerto8061();
        procesarIntentRecibido(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        procesarIntentRecibido(intent);
    }

    private void procesarIntentRecibido(Intent intent) {
        if (intent != null) {
            String extraHost = intent.getStringExtra("serverHost");
            if (extraHost == null && intent.getData() != null) {
                Uri data = intent.getData();
                extraHost = data.getQueryParameter("serverHost");
            }
            if (extraHost != null && !extraHost.trim().isEmpty()) {
                conectarARockolaHost(extraHost.trim());
                return;
            }
        }

        if (currentServerHost != null && !currentServerHost.isEmpty()) {
            verificarYConectarHostGuardado(currentServerHost);
        } else {
            mostrarPantallaBuscandoRockola("Escaneando red Wi-Fi para conectar con ROCKOBOX PLUS...");
            buscarRockolaEnRedLocal();
        }
    }

    private void conectarARockolaHost(final String hostPort) {
        currentServerHost = hostPort;
        prefs.edit().putString("serverHost", hostPort).apply();
        mainHandler.post(() -> {
            activarPantallaCompletaInmersiva();
            webView.loadUrl("http://" + hostPort + "/tv?app=androidtv");
        });
    }

    private void verificarYConectarHostGuardado(final String hostPort) {
        new Thread(() -> {
            if (probarHostRockola(hostPort, 900)) {
                conectarARockolaHost(hostPort);
            } else {
                mainHandler.post(() -> mostrarPantallaBuscandoRockola("Buscando ROCKOBOX PLUS en la red Wi-Fi..."));
                buscarRockolaEnRedLocal();
            }
        }).start();
    }

    private boolean probarHostRockola(String hostPort, int timeoutMs) {
        try {
            URL url = new URL("http://" + hostPort + "/api/tv-state");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            conn.disconnect();
            return (code == 200);
        } catch (Exception e) {
            return false;
        }
    }

    private void buscarRockolaEnRedLocal() {
        if (scanning.getAndSet(true)) return;

        new Thread(() -> {
            try {
                // 1. Probar rockobox.local:3000 primero
                if (probarHostRockola("rockobox.local:3000", 800)) {
                    scanning.set(false);
                    conectarARockolaHost("rockobox.local:3000");
                    return;
                }

                // 2. Obtener subred Wi-Fi local y escanear puerto 3000 en paralelo
                String prefijo = obtenerPrefijoSubredLocal();
                if (prefijo != null) {
                    ExecutorService pool = Executors.newFixedThreadPool(32);
                    final AtomicBoolean encontrado = new AtomicBoolean(false);

                    for (int i = 1; i <= 254; i++) {
                        final String candidato = prefijo + i + ":3000";
                        pool.submit(() -> {
                            if (encontrado.get()) return;
                            if (probarHostRockola(candidato, 600)) {
                                if (encontrado.compareAndSet(false, true)) {
                                    conectarARockolaHost(candidato);
                                }
                            }
                        });
                    }
                    pool.shutdown();
                    while (!pool.isTerminated() && !encontrado.get()) {
                        Thread.sleep(100);
                    }
                    if (encontrado.get()) {
                        scanning.set(false);
                        return;
                    }
                }
            } catch (Exception ignored) {}

            scanning.set(false);
            // Reintentar automáticamente cada 4 segundos hasta que enciendan la Rockola
            mainHandler.postDelayed(this::buscarRockolaEnRedLocal, 4000);
        }).start();
    }

    private String obtenerPrefijoSubredLocal() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                WifiInfo wi = wm.getConnectionInfo();
                int ipInt = wi.getIpAddress();
                if (ipInt != 0) {
                    return String.format("%d.%d.%d.", (ipInt & 0xff), (ipInt >> 8 & 0xff), (ipInt >> 16 & 0xff));
                }
            }
        } catch (Exception ignored) {}
        return "192.168.1.";
    }

    // Mini servidor HTTP en puerto 8061 para que la Rockola detecte la Android TV en la red y le cambie/actualice la IP al instante
    private void iniciarServidorControlRemotoPuerto8061() {
        new Thread(() -> {
            try {
                controlServerSocket = new ServerSocket();
                controlServerSocket.setReuseAddress(true);
                controlServerSocket.bind(new InetSocketAddress("0.0.0.0", 8061));
                while (!isFinishing()) {
                    Socket client = controlServerSocket.accept();
                    new Thread(() -> manejarClienteControl(client)).start();
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void manejarClienteControl(Socket client) {
        try {
            client.setSoTimeout(1500);
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            String line = reader.readLine();
            if (line != null) {
                if (line.contains("/connect?host=")) {
                    int idx = line.indexOf("/connect?host=") + 14;
                    int end = line.indexOf(" ", idx);
                    String nuevoHost = (end > idx) ? line.substring(idx, end) : line.substring(idx);
                    nuevoHost = Uri.decode(nuevoHost).trim();
                    if (!nuevoHost.isEmpty()) {
                        conectarARockolaHost(nuevoHost);
                    }
                }
            }
            String jsonResp = "{\"ok\":true,\"app\":\"ROCKOBOX PLUS TV\",\"model\":\"" + android.os.Build.MODEL + "\"}";
            String httpResp = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/json\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Content-Length: " + jsonResp.length() + "\r\n\r\n" + jsonResp;
            OutputStream out = client.getOutputStream();
            out.write(httpResp.getBytes());
            out.flush();
            client.close();
        } catch (Exception ignored) {}
    }

    private void mostrarPantallaBuscandoRockola(String subtitulo) {
        String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><style>" +
                "body{margin:0;height:100vh;background:radial-gradient(circle,#1f003d 0%,#05050a 80%);color:#fff;font-family:Arial,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;}" +
                ".box{border:3px solid #00ffcc;background:#0d0d18;padding:30px 45px;border-radius:18px;box-shadow:0 0 35px rgba(0,255,204,0.3);}" +
                "h1{color:#00ffcc;margin:0 0 12px 0;font-size:34px;}" +
                "p{color:#ffcc00;font-size:20px;margin:8px 0;}" +
                ".sub{color:#cc66ff;font-size:15px;margin-top:16px;}" +
                "</style></head><body><div class='box'>" +
                "<h1>🎸 ROCKOBOX PLUS TV</h1>" +
                "<p>" + subtitulo + "</p>" +
                "<div class='sub'>💻 SISTEMA JUKEBOX & SMART TV • BY GREEN COMPUTER</div>" +
                "</div></body></html>";
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    private void activarPantallaCompletaInmersiva() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            webView.evaluateJavascript("if(typeof activarAudioPantallaCompletaTV==='function') activarAudioPantallaCompletaTV();", null);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        activarPantallaCompletaInmersiva();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (controlServerSocket != null) controlServerSocket.close();
        } catch (Exception ignored) {}
    }
}
